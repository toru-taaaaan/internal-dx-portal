# 📂 Index: Nexus_Portal

Path: `01_Workspace\11_プロジェクト\社内DXポータル\DriveStructure\Nexus_Portal`

## 📁 Subfolders
- [[00_Private_Tanji/00_INDEX|00_Private_Tanji/]]
- [[01_Public/00_INDEX|01_Public/]]
- [[02_Shared_AIChampion/00_INDEX|02_Shared_AIChampion/]]
- [[03_Shared_InfoSys/00_INDEX|03_Shared_InfoSys/]]

## 📄 Notes
- [[PLACEMENT_PLAN]]
- [[README]]
