# 📂 Index: 01_Public

Path: `01_Workspace\11_プロジェクト\社内DXポータル\DriveStructure\Nexus_Portal\01_Public`

## 📁 Subfolders
- [[assets/00_INDEX|assets/]]

