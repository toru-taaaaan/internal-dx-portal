# 📂 Index: local_preview

Path: `01_Workspace\11_プロジェクト\社内DXポータル\local_preview`

## 📁 Subfolders
- [[assets/00_INDEX|assets/]]

